"""Late-game stress branches from a legally reached quiet overtime position."""
import argparse, asyncio, copy, json, random
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
import simulate_balance_strong as sim
ORIGINAL_FRESH = sim.fresh_state
BASE = None

async def make_late():
    game=ORIGINAL_FRESH()
    for ply in range(1,73):
        commands={1:[{'type':'make_move','from':'-4,9','to':'-3,6','more':True}],2:[{'type':'make_move','from':'4,-9','to':'3,-6','more':True}]}.get(ply,[])
        game=await sim.preview(game,commands,finish=True)
    assert game.turn_number==73 and not game.is_finished
    return game

def initialise():
    global BASE
    sim.initialise()
    BASE=asyncio.run(make_late())
    sim.fresh_state=lambda frozen=True:copy.deepcopy(BASE)

def late_worker(job):
    result=sim.worker(job)
    result['source_ply']=73
    return result

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--workers',type=int,default=4)
    args=p.parse_args();jobs=[]
    for index,style in enumerate(sim.STYLES):
        for seed in range(2):
            plan=sim.policy(style,290000+seed*100+index,index+seed)
            enemy=sim.policy('adaptive',300000+seed*100+index,index+seed+1)
            for flip in (False,True):
                jobs.append(dict(id=f'late-{style}-{seed}-{int(flip)}',seed=310000+seed*100+index,
                    white=enemy if flip else plan,black=plan if flip else enemy,width=3))
    random.Random(3031).shuffle(jobs)
    metadata=dict(config_sha256=sim.fingerprint(sim.DEFAULT_CONFIG),script_sha256=sim.hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),engine_policy_sha256=sim.hashlib.sha256(Path(sim.__file__).read_bytes()).hexdigest(),jobs=jobs)
    args.output.with_suffix('.meta.json').write_text(json.dumps(metadata,indent=2))
    done={r['id'] for r in map(json.loads,args.output.read_text().splitlines())} if args.output.exists() else set()
    with args.output.open('a') as out,ProcessPoolExecutor(max_workers=args.workers,initializer=initialise) as pool:
        futures={pool.submit(late_worker,j):j for j in jobs if j['id'] not in done}
        try:
            for future in as_completed(futures):
                result=future.result();out.write(json.dumps(result,separators=(',',':'))+'\n');out.flush();done.add(result['id'])
                print(json.dumps(dict(done=len(done),total=len(jobs),id=result['id'],winner=result['winner'],reason=result['reason'],plies=result['plies'])),flush=True)
        except BaseException:
            pool.terminate_workers();raise
if __name__=='__main__':main()
