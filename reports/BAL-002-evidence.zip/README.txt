BAL-002 evidence: 520 full games and 28 separately labelled late continuations.
Full: tournament 448, macros 48, CPU 24. Late: 28 branches from legal ply 73.
All use the shipped config hash in tournament.meta.json; ruleset revision is null.
The *.jsonl files contain exact selected commands; implicit End Turn is replayed
with finish=True. CPU traces include an explicit pass_turn. Seeded main builds
are assigned, not organic picks. CPU time-budget searches may vary on rerun.

Keep scripts together. Python 3.14 and installed server dependencies are required.
Set DJANGO_DEBUG=true, DJANGO_SETTINGS_MODULE=core.settings and PYTHONPATH to the
server directory. The scripts refuse SQL. Do not point them at a production service.

Self-check: python simulate_balance_strong.py --output check.json --self-check
Main: python simulate_balance_strong.py --output new-main.jsonl --workers 8 --seeds 8 --width 3
Holdouts: python macro_holdouts.py --output new-macros.jsonl --workers 4
CPU: python cpu_holdouts.py --output new-cpu.jsonl --workers 4
Late: python late_holdouts.py --output new-late.jsonl --workers 4
Audit: python audit_simulation.py tournament.jsonl macros.jsonl cpu.jsonl late.jsonl --output audit.json --workers 8

JSON results and *.log files record actual checks. manifest.json hashes this archive's
members. No pilot/scouting/failed calibration/performance experiment contributes to
the reported samples. Focused probes label rearranged positions and are not win-rate
samples. See reports/BAL-002-gameplay-review.md in the repository for interpretation.
