"""Replay every saved command as whole atomic turns, independent of staged search."""
import argparse, asyncio, collections, json
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
import simulate_balance_strong as s

async def replay(row):
    state=s.fresh_state();stages=set();arrivals={};commands=0
    if row.get('source_ply'):
        from late_holdouts import make_late
        state=await make_late()
        assert state.turn_number==row['source_ply']==73
    for step in row['trace']:
        assert step['ply']==state.turn_number and step['color']==s.cpu.color_of(state),row['id']
        phase=str(s.phase_index_at(state.turn_number,state.config_snapshot))
        if phase not in stages:
            assert s.metrics(state)==row['checkpoints'][phase],(row['id'],phase)
            stages.add(phase)
        arrivals.setdefault(phase+'|'+step['color'],s.metrics(state)[step['color']])
        state=await s.preview(state,step['commands'],finish=True);commands+=len(step['commands'])
    assert state.is_finished and (state.winner,state.end_reason)==(row['winner'],row['reason']),row['id']
    assert state.phase_bank==row['bank'] and s.metrics(state)==row['final_resources'],row['id']
    assert state.ability_state['paths']==row['paths'] and state.ability_state['loadouts']==row['loadouts'],row['id']
    assert s.fingerprint(state.config_snapshot)==s.fingerprint(s.DEFAULT_CONFIG)
    return dict(id=row['id'],plies=len(row['trace']),commands=commands,arrivals=arrivals)

def worker(row):return asyncio.run(replay(row))
def main():
    p=argparse.ArgumentParser();p.add_argument('files',nargs='+',type=Path);p.add_argument('--output',type=Path,required=True);p.add_argument('--workers',type=int,default=2);a=p.parse_args()
    s.initialise()
    state=s.fresh_state()
    (a.output.parent/'initial-units.json').write_text(json.dumps({u['uid']:{'unit_id':u['unit_id'],'color':u['color'],'zone':'battlefield' if k in state.board_state else 'panel'} for k,u in s.AbilityContext(state).recipients().items()},indent=2))
    rows=[json.loads(line) for path in a.files for line in path.read_text().splitlines()]
    assert len({r['id'] for r in rows})==len(rows),'Duplicate completed game ID'
    total=collections.Counter();arrivals=[]
    with ProcessPoolExecutor(max_workers=a.workers,initializer=s.initialise) as pool:
        for result in pool.map(worker,rows):
            total['games']+=1;total['plies']+=result['plies'];total['commands']+=result['commands'];arrivals.append(dict(id=result['id'],arrivals=result['arrivals']))
            if total['games']%50==0:print(json.dumps(dict(replayed=total['games'],total=len(rows))),flush=True)
    out=dict(status='pass',files=[str(f) for f in a.files],verified=dict(total),config_sha256=s.fingerprint(s.DEFAULT_CONFIG))
    a.output.with_name(a.output.stem+'-arrivals.json').write_text(json.dumps(arrivals,separators=(',',':')))
    a.output.write_text(json.dumps(out,indent=2));print(json.dumps(out),flush=True)
if __name__=='__main__':main()
