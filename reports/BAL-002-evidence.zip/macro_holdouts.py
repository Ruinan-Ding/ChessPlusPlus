"""Held-out, repeatable legal opening scripts against adaptive tactical opponents."""
import argparse, asyncio, copy, json, random
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
import simulate_balance_strong as sim
ORIGINAL = sim.choose_turn

async def scripted(state, plan, rng, width=3, max_actions=12):
    if not plan['style'].startswith('script_'):
        return await ORIGINAL(state, plan, rng, width, max_actions)
    node, commands = state, []
    async def attempt(command):
        nonlocal node
        try:
            node = await sim.preview(node, [command])
            commands.append(command)
            return True
        except sim.ValidationError:
            return False
    color = sim.cpu.color_of(node)
    await attempt({'type':'pick_pair','id':'mend'}) if not node.ability_state['loadouts'][color] else None
    if not node.ability_state['paths'][color]:
        await attempt({'type':'pick_path','id':'bastion'})
    side_turn=(state.turn_number-1)//2+1
    sign=1 if color=='white' else -1
    def at(key):
        q,r=sim.geometry.parse_coord(key)
        return sim.geometry.coord_key(sign*q,sign*r)
    first = ('-5,11' if plan['style']=='script_king_hold' else '-4,9')
    intents={1:(first,'-3,6')}
    if plan['style']=='script_bishop_tally':
        intents.update({2:('-6,10','-3,4'),4:('-3,4','0,-2'),5:('0,-2','2,-6')})
    if side_turn in intents:
        source,destination=intents[side_turn]
        await attempt({'type':'make_move','from':at(source),'to':at(destination),'more':True})
    ctx=sim.AbilityContext(node)
    for key,unit in list(ctx.recipients().items()):
        spec=node.config_snapshot['units'][unit['unit_id']]
        if unit['color']==color and key in node.board_state and spec.get('commander') and unit['hp']<unit.get('max_hp',spec['hp']):
            await attempt({'type':'cast_ability','id':'mend','targetUid':unit['uid']})
        ability=node.config_snapshot['abilities']['catalogue'].get(spec.get('ability'),{})
        if plan['style']=='script_bishop_tally' and key in node.board_state and unit['color']==color and ability.get('effect')=='control':
            for enemy_key,enemy in ctx.recipients().items():
                if enemy['color']!=color and node.config_snapshot['units'][enemy['unit_id']].get('commander') and sim.cpu.distance(key,enemy_key)<=ability.get('radius',1):
                    await attempt({'type':'cast_ability','id':spec['ability'],'unitUid':unit['uid'],'targetUid':enemy['uid']})
    return await sim.preview(node,[],finish=True),commands,[]

def initialise():
    sim.initialise()
    sim.choose_turn=scripted

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--workers',type=int,default=4)
    args=p.parse_args();jobs=[]
    for macro in ('script_king_hold','script_bishop_tally'):
        for style in ('capture','control','adaptive'):
            for seed in range(4):
                plan=sim.policy('defend',70000+seed,0);plan['style']=macro;plan['pairs']=['mend']
                enemy=sim.policy(style,80000+seed,seed)
                for flip in (False,True):
                    jobs.append(dict(id=f'{macro}-{style}-{seed}-{int(flip)}',seed=90000+seed,
                        white=enemy if flip else plan,black=plan if flip else enemy,width=3))
    random.Random(3031).shuffle(jobs)
    metadata=dict(config_sha256=sim.fingerprint(sim.DEFAULT_CONFIG),script_sha256=sim.hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),engine_policy_sha256=sim.hashlib.sha256(Path(sim.__file__).read_bytes()).hexdigest(),jobs=jobs)
    args.output.with_suffix('.meta.json').write_text(json.dumps(metadata,indent=2))
    done={r['id'] for r in map(json.loads,args.output.read_text().splitlines())} if args.output.exists() else set()
    with args.output.open('a') as out,ProcessPoolExecutor(max_workers=args.workers,initializer=initialise) as pool:
        futures={pool.submit(sim.worker,j):j for j in jobs if j['id'] not in done}
        try:
            for future in as_completed(futures):
                result=future.result();out.write(json.dumps(result,separators=(',',':'))+'\n');out.flush();done.add(result['id'])
                print(json.dumps(dict(done=len(done),total=len(jobs),id=result['id'],winner=result['winner'],reason=result['reason'],plies=result['plies'])),flush=True)
        except BaseException:
            pool.terminate_workers();raise
if __name__=='__main__':main()
