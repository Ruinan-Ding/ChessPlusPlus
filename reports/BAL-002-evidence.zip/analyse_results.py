import collections, json, math, random, statistics
from pathlib import Path
E=Path(__file__).parent

def summary(values):
    a=sorted(values)
    if not a:return None
    def quantile(q):return a[round((len(a)-1)*q)]
    return dict(n=len(a),mean=round(statistics.mean(a),2),p10=quantile(.1),median=statistics.median(a),p90=quantile(.9),min=a[0],max=a[-1])

def wilson(w,n):
    if not n:return None
    z=1.95996398454;p=w/n;d=1+z*z/n
    centre=(p+z*z/(2*n))/d;half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/d
    return [round(centre-half,4),round(centre+half,4)]

def analyse(rows):
    styles=collections.defaultdict(lambda:collections.Counter())
    matches=collections.defaultdict(lambda:collections.Counter())
    builds=collections.defaultdict(lambda:collections.Counter())
    selected=collections.Counter();uses=collections.Counter();opps=collections.Counter();ability_games=collections.Counter()
    actors=[];abilities_per_side=[];resource=collections.defaultdict(lambda:collections.defaultdict(list));groups=collections.defaultdict(list)
    for r in rows:
        for color in ('white','black'):
            enemy='black' if color=='white' else 'white'
            style=r['plans'][color]['style'];opponent=r['plans'][enemy]['style'];win=int(r['winner']==color)
            result='wins' if win else 'draws' if not r['winner'] else 'losses'
            styles[style]['n']+=1;styles[style][result]+=1;styles[style][color+'_'+result]+=1
            matches[style+'|'+opponent]['n']+=1;matches[style+'|'+opponent][result]+=1
            key=style+'|'+r['plans'][color]['path'];builds[key]['n']+=1;builds[key][result]+=1
            actual=r['paths'][color] or 'not_purchased';selected['path|'+actual]+=1
            for a in r['loadouts'][color]:selected['pool|'+a]+=1
            casts={k.split('|',1)[1]:v for k,v in r['casts'].items() if k.startswith(color+'|')}
            uses.update(casts);ability_games.update(casts.keys())
            opps.update({k.split('|',1)[1]:v for k,v in r['opportunities'].items() if k.startswith(color+'|')})
            actors.append(sum(a.startswith(color+'|') for a in r['actors']))
            abilities_per_side.append(sum(casts.values()))
            for stage,rec in r['checkpoints'].items():
                for k,v in rec[color].items():resource[stage][k].append(v)
        group=r['id'].rsplit('-',1)[0]
        groups[group].append(r)
    paired={}
    rng=random.Random(234329)
    for style in styles:
        clusters=[]
        for cluster in groups.values():
            scores=[]
            for r in cluster:
                for color in ('white','black'):
                    enemy='black' if color=='white' else 'white'
                    if r['plans'][color]['style']==style and r['plans'][enemy]['style']!=style:
                        scores.append(1 if r['winner']==color else .5 if not r['winner'] else 0)
            if scores:clusters.append(scores)
        if not clusters:continue
        rates=[]
        for _ in range(3000):
            sample=[v for j in range(len(clusters)) for v in rng.choice(clusters)]
            rates.append(statistics.mean(sample))
        paired[style]=dict(nonmirror_games=sum(map(len,clusters)),paired_seed_clusters=len(clusters),score=round(statistics.mean(v for c in clusters for v in c),4),bootstrap95=[round(sorted(rates)[74],4),round(sorted(rates)[2924],4)])
    return dict(games=len(rows),plies=sum(r['plies'] for r in rows),endings=dict(collections.Counter(r['reason'] for r in rows)),winner=dict(collections.Counter(r['winner'] for r in rows)),length=summary([r['plies'] for r in rows]),styles=dict(styles),paired=paired,matchups=dict(matches),builds=dict(builds),selections=dict(selected),uses=dict(uses),ability_games=dict(ability_games),considered_legal_turns=dict(opps),actors_per_side=summary(actors),casts_per_side=summary(abilities_per_side),checkpoints={stage:{k:summary(v) for k,v in row.items()} for stage,row in resource.items()},reached_plies={str(p):sum(r['plies']>=p for r in rows) for p in (7,17,27,29,39,49,51,61,71,73,89,99)},previews=sum(r['counters'].get('previews',0) for r in rows),tactical_bundles=sum(r['counters'].get('tactical_bundles',0) for r in rows))

if __name__=='__main__':
    out={}
    for name in ('tournament','macros','cpu','late'):
        p=E/(name+'.jsonl')
        if p.exists():out[name]=analyse([json.loads(line) for line in p.read_text().splitlines()])
    (E/'aggregate.json').write_text(json.dumps(out,indent=2))
    print(json.dumps({name:{k:v for k,v in data.items() if k in ('games','plies','endings','winner','length','paired','actors_per_side','reached_plies')} for name,data in out.items()},indent=2))
