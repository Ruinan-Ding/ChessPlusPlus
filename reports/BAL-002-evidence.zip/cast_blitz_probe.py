"""Legal tally combo and an earlier counter; enumerate immediate damage responses."""
import asyncio, copy, json
from pathlib import Path
import simulate_balance_strong as s
from game.engine.scoring import deaths_of, unit_value

async def setup(stop=69):
    game=s.fresh_state()
    intents={1:('-4,9','-3,6'),2:('5,-11','3,-6'),3:('-6,10','-3,4'),7:('-3,4','0,-2'),9:('0,-2','2,-6')}
    while game.turn_number<stop:
        pair=intents.get(game.turn_number)
        commands=[{'type':'make_move','from':pair[0],'to':pair[1],'more':True}] if pair else []
        if game.turn_number==2:commands.insert(0,{'type':'pick_pair','id':'mend'})
        if game.turn_number==8:commands.insert(0,{'type':'pick_pair','id':'warcry'})
        game=await s.preview(game,commands,finish=True)
    return game

async def main():
    game=await setup();source=game.board_state['2,-6']['uid'];target=game.board_state['3,-6']['uid']
    commands=[{'type':'pick_path','id':'tempo'},{'type':'cast_ability','id':'bishop-cast','unitUid':source,'targetUid':target},{'type':'cast_ability','id':'blitz'}]
    locked=await s.preview(game,commands,finish=True)
    refusals={}
    for label,reply in [('normal_attack',[{'type':'make_move','from':'2,-10','to':'2,-7','attack':'2,-6','more':True}]),('counter_cast',[{'type':'make_move','from':'4,-10','to':'3,-5','more':True},{'type':'cast_ability','id':'bishop-cast','unitUid':'b4,-10','targetUid':target}])]:
        try:await s.preview(locked,reply,finish=True);raise AssertionError('Expected action lock')
        except s.ValidationError as error:refusals[label]=str(error)
    # Every drawn hex, including panels and empty centres; strongest damaging CP path.
    prepared=await s.preview(locked,[{'type':'pick_path','id':'onslaught'},{'type':'cast_ability','id':'ruin'}])
    tested=0;best=None
    for cell in s.panels.grid_coords(11):
        centre=cell['key']
        try:child=await s.preview(prepared,[{'type':'cast_ability','id':'cleave','hex':centre}])
        except s.ValidationError:continue
        victims=sorted((u for u in s.AbilityContext(child).recipients().values() if u['color']=='white' and u['hp']<=4),key=lambda u:unit_value(child.config_snapshot,u['unit_id'],'attrition'),reverse=True)
        strike=[]
        for victim in victims:
            command={'type':'cast_ability','id':'strike','targetUid':victim['uid']}
            try:child=await s.preview(child,[command]);strike=[command];break
            except s.ValidationError:continue
        child=await s.preview(child,[],finish=True)
        score=child.phase_bank['3'];lead=score['white']-score['black'];tested+=1
        if best is None or lead<best['lead']:
            best=dict(lead=lead,bank=copy.deepcopy(child.phase_bank),centre=centre,strike=strike,white_losses=deaths_of(child.config_snapshot,child.move_history,'white',3))
        assert lead>50,(centre,score)
    # The broad preemptive counter is available BEFORE the final cast.
    previous=await setup(68)
    previous=await s.preview(previous,[{'type':'pick_path','id':'tempo'},{'type':'cast_ability','id':'blitz'}],finish=True)
    try:await s.preview(previous,commands,finish=True);raise AssertionError('Expected preemptive lock')
    except s.ValidationError as error:preempted=str(error)
    previous=await s.preview(previous,[{'type':'pick_path','id':'tempo'},{'type':'cast_ability','id':'blitz'}],finish=True)
    previous=await s.preview(previous,[],finish=True)
    assert previous.phase_bank['3']=={'white':171,'black':171}
    out=dict(arranged_position=False,source_ply=69,combo=commands,normal_responses_refused=refusals,cleave_centres_tested=tested,best_immediate_damage_response=best,preemptive_black_blitz_blocks_cast=preempted,preempted_bank=previous.phase_bank,
      limits='Delivery was cooperative. Cleave/Ruin/Strike response order uses healthy-unit damage thresholds; this is not an exhaustive game solver. Earlier denial remains possible.')
    Path('/analysis/cast-blitz-results.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2),flush=True)
s.initialise();asyncio.run(main())
