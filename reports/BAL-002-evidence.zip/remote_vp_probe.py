"""Legally reached board-wide casualty scoring and preventive counters."""
import asyncio, json
from pathlib import Path
import simulate_balance_strong as s

async def setup(zone='home',fortress=False):
    game=s.fresh_state()
    intents={1:('-4,9','-3,6'),2:('4,-9','3,-6')}
    if zone=='side':intents.update({3:('0,10','2,6'),7:('2,6','5,2'),9:('5,2','7,0')})
    if zone=='middle':intents.update({3:('0,10','2,6'),7:('2,6','2,2'),9:('2,2','0,0')})
    while game.turn_number<70:
        pair=intents.get(game.turn_number)
        commands=[{'type':'make_move','from':pair[0],'to':pair[1],'more':True}] if pair else []
        if game.turn_number==2:commands.insert(0,{'type':'pick_pair','id':'mend'})
        if fortress and game.turn_number==69:commands.extend([{'type':'pick_path','id':'bastion'},{'type':'cast_ability','id':'fortress'}])
        game=await s.preview(game,commands,finish=True)
    return game

async def branch(zone='home',fortress=False,strong=False):
    game=await setup(zone,fortress)
    commands=[{'type':'pick_path','id':'onslaught'}]
    if strong:commands.append({'type':'cast_ability','id':'ruin'})
    commands.extend([{'type':'cast_ability','id':'cleave','hex':'-15,11' if strong else '-15,10'},{'type':'cast_ability','id':'strike','targetUid':'w-14,11' if strong else 'w-15,10'}])
    game=await s.preview(game,commands,finish=True)
    bank=json.loads(json.dumps(game.phase_bank))
    while not game.is_finished:game=await s.preview(game,[],finish=True)
    return dict(zone=zone,fortress=fortress,strong_burst=strong,commands=commands,bank=bank,winner=game.winner,reason=game.end_reason)

async def main():
    result={name:await branch(*args) for name,args in [('cheap_tied',()),('fortress_counter',('home',True)),('side_zone_counter',('side',)),('central_lead_erased',('middle',False,True))]}
    assert result['cheap_tied']['winner']=='black' and result['cheap_tied']['reason']=='points'
    assert result['cheap_tied']['bank']['3']=={'white':135,'black':171}
    assert result['fortress_counter']['bank']['3']=={'white':171,'black':171}
    assert result['side_zone_counter']['winner']=='white' and result['side_zone_counter']['reason']=='points'
    assert result['central_lead_erased']['bank']['3']=={'white':93,'black':171}
    assert result['central_lead_erased']['reason']=='overtime'
    Path('/analysis/remote-vp-results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2),flush=True)
s.initialise();asyncio.run(main())
