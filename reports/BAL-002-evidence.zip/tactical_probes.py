"""Arranged tactical forks using the current preset's legal turn handlers."""
import asyncio, copy, json
from pathlib import Path
import simulate_balance_strong as s

async def baseline():
    game=s.fresh_state()
    while game.turn_number<51:
        commands={1:[{'type':'make_move','from':'-4,9','to':'-3,6','more':True}],2:[{'type':'make_move','from':'4,-9','to':'3,-6','more':True}]}.get(game.turn_number,[])
        game=await s.preview(game,commands,finish=True)
    assert not game.is_finished
    return game

def position(base,shield=False,archer=False):
    game=copy.deepcopy(base)
    game.board_state['0,0']=game.board_state.pop('-5,11');game.board_state['0,0']['hp']=6
    game.board_state['8,0']=game.board_state.pop('6,-11')
    if shield:game.board_state['1,-1']=game.board_state.pop('-8,11')
    if archer:game.board_state['8,-3']=game.board_state.pop('-10,11')
    return game

async def attempt(game,commands):
    try:
        out=await s.preview(game,commands,finish=True)
        return dict(accepted=True,winner=out.winner,reason=out.end_reason,king=next((u['hp'] for u in out.board_state.values() if u['uid']=='w-5,11'),0)),out
    except s.ValidationError as err:
        return dict(accepted=False,reason=str(err)),game

async def main():
    base=await baseline();results={}
    attack={'type':'make_move','from':'8,0','to':'1,0','attack':'0,0','more':True}
    game=await s.preview(position(base),[],finish=True)
    results['unprotected'],_=await attempt(game,[attack])
    assert results['unprotected']['winner']=='black'
    game=position(base)
    game=await s.preview(game,[{'type':'pick_pair','id':'dash'},{'type':'cast_ability','id':'mire','targetUid':'b6,-11'}],finish=True)
    results['mire_blocks_unassisted'],_=await attempt(game,[attack])
    results['dash_counters_mire'],_=await attempt(game,[{'type':'pick_pair','id':'dash'},{'type':'cast_ability','id':'dash','targetUid':'b6,-11'},attack])
    assert not results['mire_blocks_unassisted']['accepted'] and results['dash_counters_mire']['winner']=='black'
    game=position(base)
    game=await s.preview(game,[{'type':'pick_path','id':'tempo'},{'type':'cast_ability','id':'surge','hex':'8,0'}],finish=True)
    results['trap_blocks_attacker'],_=await attempt(game,[attack])
    assert not results['trap_blocks_attacker']['accepted']
    game=position(base,shield=True)
    game=await s.preview(game,[{'type':'cast_ability','id':game.config_snapshot['units']['shieldman']['ability'],'unitUid':game.board_state['1,-1']['uid']}],finish=True)
    results['taunt_blocks_king_target'],_=await attempt(game,[attack])
    results['taunt_allows_guard_target'],_=await attempt(game,[{**attack,'attack':'1,-1'}])
    assert not results['taunt_blocks_king_target']['accepted'] and results['taunt_allows_guard_target']['accepted']
    game=position(base,archer=True);uid=game.board_state['8,-3']['uid']
    game=await s.preview(game,[{'type':'cast_ability','id':game.config_snapshot['units']['archer']['ability'],'unitUid':uid},{'type':'make_move','from':'8,-3','to':'8,-3','attack':'8,0','more':True}],finish=True)
    results['snare_blocks_following_queen_rush'],_=await attempt(game,[attack])
    assert not results['snare_blocks_following_queen_rush']['accepted']
    # A passive Black hold is beatable by one extra White scoring zone.
    game=s.fresh_state()
    intents={1:('-4,9','-3,6'),2:('4,-9','3,-6'),3:('0,10','2,6'),7:('2,6','5,2'),9:('5,2','7,0')}
    while not game.is_finished:
        pair=intents.get(game.turn_number)
        commands=[{'type':'make_move','from':pair[0],'to':pair[1],'more':True}] if pair else []
        game=await s.preview(game,commands,finish=True)
    results['extra_zone_beats_passive_black_hold']=dict(winner=game.winner,reason=game.end_reason,bank=game.phase_bank)
    assert game.winner=='white' and game.end_reason=='points'
    result=dict(config_sha256=s.fingerprint(s.DEFAULT_CONFIG),arranged_position=True,checks=results)
    Path('/analysis/tactical-results.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2),flush=True)
s.initialise();asyncio.run(main())
