"""Independent production CPU search against the experimental tactical policies."""
import argparse, asyncio, copy, json, random
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
import simulate_balance_strong as sim
ORIGINAL = sim.choose_turn

async def scripted(state, plan, rng, width=3, max_actions=12):
    if not plan['style'].startswith('cpu_'):
        return await ORIGINAL(state, plan, rng, width, max_actions)
    difficulty=plan['style'].split('_',1)[1]
    budget=2 if difficulty=='normal' else 5
    commands=await sim.cpu.search_turn(state,difficulty,budget)
    final=await sim.preview(state,commands,finish=False)
    return final,commands,[]

def initialise():
    sim.initialise()
    sim.choose_turn=scripted

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--workers',type=int,default=4)
    args=p.parse_args();jobs=[]
    for difficulty,seeds in (('normal',2),('hard',1)):
        for style in ('capture','rush','control','adaptive'):
            for seed in range(seeds):
                plan=sim.policy('adaptive',170000+seed,seed);plan['style']='cpu_'+difficulty
                enemy=sim.policy(style,180000+seed,seed)
                for flip in (False,True):
                    jobs.append(dict(id=f'cpu_{difficulty}-{style}-{seed}-{int(flip)}',seed=190000+seed,
                        white=enemy if flip else plan,black=plan if flip else enemy,width=3))
    random.Random(3031).shuffle(jobs)
    metadata=dict(config_sha256=sim.fingerprint(sim.DEFAULT_CONFIG),script_sha256=sim.hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),engine_policy_sha256=sim.hashlib.sha256(Path(sim.__file__).read_bytes()).hexdigest(),jobs=jobs)
    args.output.with_suffix('.meta.json').write_text(json.dumps(metadata,indent=2))
    done={r['id'] for r in map(json.loads,args.output.read_text().splitlines())} if args.output.exists() else set()
    with args.output.open('a') as out,ProcessPoolExecutor(max_workers=args.workers,initializer=initialise) as pool:
        futures={pool.submit(sim.worker,j):j for j in jobs if j['id'] not in done}
        try:
            for future in as_completed(futures):
                result=future.result();out.write(json.dumps(result,separators=(',',':'))+'\n');out.flush();done.add(result['id'])
                print(json.dumps(dict(done=len(done),total=len(jobs),id=result['id'],winner=result['winner'],reason=result['reason'],plies=result['plies'])),flush=True)
        except BaseException:
            pool.terminate_workers();raise
if __name__=='__main__':main()
