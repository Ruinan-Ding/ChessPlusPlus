import os,sys,json
from pathlib import Path
os.environ['DJANGO_DEBUG']='true'
root=Path.cwd();sys.path.insert(0,str(root/'server'))
import simulate_balance_strong as s
s.initialise()
e=Path(__file__).parent;metadata=json.loads((e/'tournament.meta.json').read_text())
jobs=s.schedule(8,3);rows=list(map(json.loads,(e/'tournament.jsonl').read_text().splitlines()))
assert s.fingerprint(jobs)==metadata['jobs_sha256']
expected={j['id']:j for j in jobs}
assert len(rows)==448 and len({r['id'] for r in rows})==448 and {r['id'] for r in rows}==set(expected)
for row in rows:
 job=expected[row['id']]
 assert row['seed']==job['seed'] and row['plans']=={c:job[c] for c in ('white','black')}
assert s.fingerprint(s.DEFAULT_CONFIG)==metadata['config_sha256']
assert s.cpu.TUNING==metadata['cpu_tuning']
print(json.dumps(dict(status='pass',scheduled_games=448,matched_completed_ids=448,plans_seeds_config_tuning='unchanged')))
