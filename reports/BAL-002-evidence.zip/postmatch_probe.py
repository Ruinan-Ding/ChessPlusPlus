import asyncio, copy, json
from pathlib import Path
import simulate_balance_strong as s
async def main():
 game=s.fresh_state()
 while game.turn_number<71:
  cmds={1:[{'type':'make_move','from':'-4,9','to':'-3,6','more':True}],2:[{'type':'make_move','from':'4,-9','to':'3,-6','more':True}]}.get(game.turn_number,[])
  game=await s.preview(game,cmds,finish=True)
 game.board_state['1,-1']=game.board_state.pop('-5,11');game.board_state['2,-1']=game.board_state.pop('5,-11')
 king=game.board_state['2,-1'];before=king['hp'];uid=king['uid'];caster=game.board_state['1,-1']['uid']
 commands=[{'type':'pick_path','id':'onslaught'},{'type':'pick_pair','id':'mend'},{'type':'cast_ability','id':'cleave','hex':'2,-1'},{'type':'cast_ability','id':'ruin'},{'type':'cast_ability','id':'strike','targetUid':uid},{'type':'cast_ability','id':game.config_snapshot['units']['king']['ability'],'unitUid':caster}]
 out=await s.preview(game,commands,finish=False)
 after=next(u['hp'] for u in out.board_state.values() if u['uid']==uid)
 result=dict(arranged_position=True,ply=71,commands=commands,king_hp_before=before,king_hp_after=after,damage=before-after,finished=out.is_finished)
 assert before==60 and before-after==13 and not out.is_finished
 Path('/analysis/postmatch-results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2),flush=True)
s.initialise();asyncio.run(main())
