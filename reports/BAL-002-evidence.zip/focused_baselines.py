import simulate_balance_strong as sim
sim.initialise()
"""Read-only gameplay probes against the real atomic engine; no saved models."""
import asyncio, copy, json, os, traceback
from pathlib import Path
os.environ.setdefault('DJANGO_SETTINGS_MODULE','core.settings')
import django
django.setup()
from game.models import GameState
from game.consumers import GameConsumer
from game.engine.config_loader import DEFAULT_CONFIG, build_initial_board
from game.engine.ability_rules import initial_state, AbilityContext
from game.engine import panels
from game.engine.economy import unit_points_of, points_of
from game.engine.scoring import cap_of, deaths_of
from game.engine.unit_stats import unit_stats
from game.engine.game_logic import strike_damage

OUT=Path(__file__).parent
runner=GameConsumer()
results={}

def fresh():
 return sim.fresh_state()

def wallets(s):
 ctx=AbilityContext(s)
 out={}
 for col in ['white','black']:
  ctx.color=col
  out[col]={'points':points_of(col,s.turn_number,s.move_history,s.config_snapshot,s.phase_bank)+ctx.data['pointDelta'][col],'UP':unit_points_of(col,s.move_history,s.config_snapshot),'CP':ctx.cp(),'capture':cap_of(s.board_state,11,col,s.config_snapshot),'king':next(({'hp':u['hp'],'vet':u.get('vet',0)} for u in s.board_state.values() if s.config_snapshot['units'][u['unit_id']].get('commander') and u.get('owner',u['color'])==col),None)}
 return out

def emit(name,value):
 results[name]=value
 (OUT/'probe-results.json').write_text(json.dumps(results,indent=2))
 print(name, json.dumps(value),flush=True)

async def run_homegame(mend=False, invade=False):
 s=fresh(); checkpoints={}; ledger=[]
 while not s.is_finished:
  checkpoints[s.turn_number]=copy.deepcopy(s)
  commands=[]
  if s.turn_number==1: commands=[{'type':'make_move','from':'-4,9','to':'-3,6','more':True}]
  if s.turn_number==2:
   commands=[{'type':'make_move','from':('5,-11' if invade else '4,-9'),'to':'3,-6','more':True}]
   if mend: commands.insert(0,{'type':'pick_pair','id':'mend'})
  if invade and s.turn_number in [3,7,9]:
   fr,to={3:('-6,10','-3,4'),7:('-3,4','0,-2'),9:('0,-2','2,-6')}[s.turn_number]
   commands=[{'type':'make_move','from':fr,'to':to,'more':True}]
  if mend and s.turn_number>=74 and s.turn_number%2==0:
   king=next(u for u in s.board_state.values() if u['unit_id']=='king' and u['color']=='black')
   commands=[{'type':'cast_ability','id':'mend','targetUid':king['uid']}]
  before=s.turn_number
  s=await runner._preview_turn(s,commands)
  if s.turn_number in [7,17,27,28,39,49,50,61,71,72,73,74,89,90,99,100,101]: ledger.append({'ply':s.turn_number,'wallets':wallets(s),'bank':copy.deepcopy(s.phase_bank)})
  if s.turn_number<=before and not s.is_finished: raise RuntimeError('Did not advance')
 emit('legal_invasion_baseline' if invade else 'home_only_with_mend' if mend else 'home_only',{'winner':s.winner,'reason':s.end_reason,'turns':(s.turn_number-1)//2,'ledger':ledger,'final':wallets(s)})
 return checkpoints

async def withdraw(s,fromkey):
 ctx=AbilityContext(s)
 targets=panels.homecoming_targets(s.config_snapshot,11,ctx.recipients(),s.board_state,fromkey)
 if not targets: raise ValueError('No homecoming targets from '+fromkey)
 to=min(targets,key=lambda k:(targets[k],k))
 before=unit_points_of('white',s.move_history,s.config_snapshot)
 s=await runner._preview_turn(s,[{'type':'make_move','from':fromkey,'to':to,'withdraw':True,'more':True}],finish=False)
 record=next(m for m in reversed(s.move_history) if m.get('withdrawn'))
 return s,{'from':fromkey,'to':to,'refund':unit_points_of('white',s.move_history,s.config_snapshot)-before,'recorded':record.get('refund'),'rank_after':record['unit'].get('vet'),'type':record['unit_id']}

async def veteran_returns(checkpoints):
 s=copy.deepcopy(checkpoints[49]); before=wallets(s)
 moves=[{'type':'panel_move','from':src,'to':dst} for src,dst in [('-12,11','-12,8'),('-12,10','-12,7'),('-12,9','-12,6')]]
 s=await runner._preview_turn(s,moves,finish=False)
 records=[]
 for key in ['-6,10','-6,11','-8,10']:
  s,record=await withdraw(s,key); records.append(record)
 s=await runner._preview_turn(s,[])
 emit('idle_veteran_returns',{'before':before,'withdrawals':records,'after':wallets(s),'bank':s.phase_bank,'deaths':deaths_of(s.config_snapshot,s.move_history,'white',2)})

async def promote_arbitrage(checkpoints):
 s=copy.deepcopy(checkpoints[27])
 s=await runner._preview_turn(s,[{'type':'pick_path','id':'bastion'},{'type':'panel_move','from':'-12,11','to':'-12,8'}],finish=False)
 plain,plain_record=await withdraw(copy.deepcopy(s),'-6,11')
 queen=s.board_state['-6,11']
 enhanced=await runner._preview_turn(s,[{'type':'cast_ability','id':'strengthen','targetUid':queen['uid']}],finish=False)
 enhanced,enhanced_record=await withdraw(enhanced,'-6,11')
 emit('strengthen_refund_arbitrage',{'ordinary':plain_record,'strengthened':enhanced_record,'extra_UP':enhanced_record['refund']-plain_record['refund'],'extra_CP':wallets(plain)['white']['CP']-wallets(enhanced)['white']['CP']})

async def sacrifice_bank(checkpoints):
 s=copy.deepcopy(checkpoints[49]); before=wallets(s); bank=copy.deepcopy(s.phase_bank)
 caster=s.board_state['-11,11']; king=s.board_state['-5,11']
 s=await runner._preview_turn(s,[{'type':'cast_ability','id':s.config_snapshot['units']['pawn']['ability'],'unitUid':caster['uid'],'targetUid':king['uid']}],finish=False)
 emit('postmatch_sacrifice',{'before':before,'after':wallets(s),'bank_before':bank,'bank_after':s.phase_bank,'phase_2_deaths':deaths_of(s.config_snapshot,s.move_history,'white',2),'buffs':s.ability_state['buffs'].get(king['uid']),'extra_actions':[m for m in s.move_history if m.get('battlefieldActions') and m.get('turn')==49]})

async def king_cast(checkpoints,kill_caster=False,legal=False):
 s=copy.deepcopy(checkpoints[69]); board=s.board_state
 if not legal:
  board['3,-5']=board.pop('3,-6'); board['3,-6']=board.pop('5,-11'); board['2,-6']=board.pop('-6,10')
 blackking=board['3,-6']; caster=board['2,-6']
 pre=wallets(s)
 s=await runner._preview_turn(s,[{'type':'cast_ability','id':'bishop-cast','unitUid':caster['uid'],'targetUid':blackking['uid']}])
 after_cast=wallets(s)
 commands=[{'type':'make_move','from':'2,-10','to':'2,-7','attack':'2,-6','more':True}] if kill_caster else []
 s=await runner._preview_turn(s,commands)
 bank=copy.deepcopy(s.phase_bank); returned_king=next(u for u in s.board_state.values() if u['uid']==blackking['uid'])
 while not s.is_finished and s.turn_number<=72: s=await runner._preview_turn(s,[])
 emit(('legal_' if legal else '')+('king_cast_caster_killed' if kill_caster else 'king_cast'),{'arranged_position':not legal,'before':pre,'after_cast':after_cast,'bank_at_tally':bank,'king_after_expiry':{'color':returned_king['color'],'owner':returned_king.get('owner')},'caster_survives':any(u['uid']==caster['uid'] for u in s.board_state.values()),'winner':s.winner,'reason':s.end_reason})

async def recharge(checkpoints):
 s=copy.deepcopy(checkpoints[27]); cmds=[{'type':'pick_pair','id':'warcry'},{'type':'pick_path','id':'tempo'}]
 s=await runner._preview_turn(s,cmds,finish=False); before=wallets(s)
 s=await runner._preview_turn(s,[{'type':'cast_ability','id':'recharge','pairId':'warcry'}],finish=False)
 emit('ready_pair_recharge',{'before':before,'after':wallets(s),'cooldowns':s.ability_state['cooldowns']['white']})


async def king_withdrawal(checkpoints):
 s=copy.deepcopy(checkpoints[49])
 s=await runner._preview_turn(s,[{'type':'panel_move','from':'-12,11','to':'-12,8'}],finish=False)
 if not panels.homecoming_targets(s.config_snapshot,11,AbilityContext(s).recipients(),s.board_state,'-5,11'):
  emit('king_withdrawal_outcome',{'offered':False,'commander_guard':'working'});return
 s,record=await withdraw(s,'-5,11')
 beforepass={'finished':s.is_finished,'kings':wallets(s)}
 s=await runner._preview_turn(s,[])
 emit('king_withdrawal_outcome',{'withdrawal':record,'before_pass':beforepass,'winner':s.winner,'reason':s.end_reason,'after':wallets(s)})

async def counter_cast(checkpoints):
 s=copy.deepcopy(checkpoints[69]);king=s.board_state['3,-6'];bishop=s.board_state['2,-6']
 s=await runner._preview_turn(s,[{'type':'cast_ability','id':'bishop-cast','unitUid':bishop['uid'],'targetUid':king['uid']}])
 uid=s.board_state['4,-10']['uid']
 commands=[{'type':'make_move','from':'4,-10','to':'3,-5','more':True},{'type':'cast_ability','id':'bishop-cast','unitUid':uid,'targetUid':king['uid']}]
 s=await runner._preview_turn(s,commands)
 bank=copy.deepcopy(s.phase_bank)
 while not s.is_finished:s=await runner._preview_turn(s,[])
 emit('legal_counter_cast',{'commands':commands,'bank':bank,'winner':s.winner,'reason':s.end_reason})

async def main():
 checkpoints=await run_homegame()
 await run_homegame(True)
 legal=await run_homegame(invade=True)
 await king_cast(legal,legal=True)
 await king_cast(legal,True,legal=True)
 await counter_cast(legal)
 await king_withdrawal(checkpoints)
 for name,fn in [('idle_returns',veteran_returns),('promotion',promote_arbitrage),('sacrifice',sacrifice_bank),('king_cast',king_cast),('king_cast_kill',lambda c:king_cast(c,True)),('recharge',recharge)]:
  try: await fn(checkpoints)
  except Exception as e:
   emit(name+'_error',{'type':type(e).__name__,'error':str(e),'traceback':traceback.format_exc()})
 c=DEFAULT_CONFIG
 matrix={}
 for a in ['pawn','archer','rook','knight','queen','king']:
  stats=unit_stats(a,c,2); distance=stats.get('attackMinRange',1)
  matrix[a]={d:strike_damage(stats,unit_stats(d,c,2),distance,c) for d in ['pawn','archer','shieldman','rook','knight','bishop','queen','king']}
 emit('veteran_damage_per_hit_at_minimum_range',matrix)
 emit('shield_counter',{d:strike_damage({'attack':4,'attackRange':1},unit_stats(d,c,2),1,c) for d in ['pawn','archer','rook','knight','bishop','queen','king']})

asyncio.run(main())
