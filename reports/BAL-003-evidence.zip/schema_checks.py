import os,sys,json,copy
from pathlib import Path
os.environ.update(DJANGO_DEBUG='true',DJANGO_SETTINGS_MODULE='core.settings')
root=Path(r'C:\Users\DRuin\OneDrive\Documents\ChessPlusPlus');sys.path.insert(0,str(root/'server'))
from jsonschema import Draft7Validator
from game.engine.config_loader import DEFAULT_CONFIG,load_config,build_initial_board
from game.engine.game_rules import PREVIOUS_CONFIG
schema=json.loads((root/'shared/game-config.schema.json').read_text(encoding='utf-8'));Draft7Validator.check_schema(schema)
for source in (DEFAULT_CONFIG,PREVIOUS_CONFIG):
 for value in (False,True,'absent'):
  raw=copy.deepcopy(source);entry=raw['abilities']['catalogue']['bishop-cast']
  if value=='absent':entry.pop('allowCommanders',None)
  else:entry['allowCommanders']=value
  before=copy.deepcopy(raw);config=load_config(raw)
  assert raw==before
  assert config==load_config(config)
  current=config['abilities']['catalogue']['bishop-cast']
  assert ('allowCommanders' not in current) if value=='absent' else current['allowCommanders'] is value
  build_initial_board(config)
assert DEFAULT_CONFIG['ruleset']['revision'] is None
assert DEFAULT_CONFIG['abilities']['catalogue']['bishop-cast']['allowCommanders'] is False
print('PASS schema; current/legacy false, true and omission; migration idempotence; input preservation; initial board; draft revision')
