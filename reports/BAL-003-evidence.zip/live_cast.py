import os,sys,json,uuid,time
from pathlib import Path
root=Path(r'C:\Users\DRuin\OneDrive\Documents\ChessPlusPlus')
sys.path.insert(0,str(root/'server/scripts/e2e'))
from wslib import WS,check,results
names=['CastA'+uuid.uuid4().hex[:6],'CastB'+uuid.uuid4().hex[:6]];sockets=[]
try:
 lobby=[]
 for name in names:
  ws=WS('/ws/game/lobby/');sockets.append(ws);ws.type('connection_established')
  ws.send({'type':'join_lobby','username':name,'secret':name+'-secret'});lobby.append(ws)
 lobby[0].until(lambda m:m.get('type')=='user_list' and names[1] in json.dumps(m),'both users')
 lobby[0].send({'type':'game_challenge','challenger':names[0],'opponent':names[1]});lobby[1].type('game_challenge')
 lobby[1].send({'type':'challenge_accept','challenger':names[0],'opponent':names[1]})
 seats=[ws.type('challenge_accepted') for ws in lobby];game=seats[0]['gameId'];players=[]
 for name,seat in zip(names,seats):
  ws=WS('/ws/game/'+game+'/');sockets.append(ws);ws.type('connection_established')
  ws.send({'type':'join_game_room','gameId':game,'username':name,'token':seat['token'],'secret':name+'-secret'})
  ws.type('join_game_room_success');players.append(ws)
 config=json.loads((root/'shared/default-config.json').read_text(encoding='utf-8'));config['match']['turnTimeLimit']=0
 config['veterancy']['startingRank']=3;config['stageRules']['opening']['unitAbilities']=True;config['economy']['upAtStart']=100
 config['setup']={'white':{'-8,0':'king','0,0':'bishop','-7,1':'pawn'},'black':{'1,0':'king','0,1':'pawn','-7,0':'bishop'}}
 players[0].send({'type':'change_game_mode','gameId':game,'mode':'custom','options':{}});players[0].type('game_mode_changed')
 players[0].send({'type':'set_custom_config','config':config});players[0].type('custom_config_saved')
 for name,ws in zip(names,players):ws.send({'type':'player_ready','gameId':game,'username':name})
 players[0].until(lambda m:m.get('type')=='player_ready' and m.get('username')==names[1],'both ready')
 players[0].send({'type':'start_game','gameId':game,'hostColor':'white','turnTimeLimit':0})
 state=players[0].type('game_started');players[1].type('game_started')
 check('fresh online config prohibits commander Cast',state['config']['abilities']['catalogue']['bishop-cast']['allowCommanders'] is False)
 def uid(at):return state['boardState'][at]['uid']
 for index,source,king,ordinary in [(0,'0,0','1,0','0,1'),(1,'-7,0','-8,0','-7,1')]:
  ws=players[index];bad={'type':'cast_ability','id':'bishop-cast','unitUid':uid(source),'targetUid':uid(king)}
  base={'gameId':game,'turnNumber':state['turnNumber'],'revision':state['revision']}
  ws.send(dict(base,type='save_turn_draft',sequence=1,commands=[bad]));error=ws.type('error')
  check('king Cast refused for '+str(index), 'commander' in json.dumps(error).lower(),error)
  ws.send({'type':'request_game_state','gameId':game});unchanged=ws.type('game_state_update')
  check('rejection preserves board, ply and revision '+str(index),all(unchanged[k]==state[k] for k in ('boardState','turnNumber','revision')))
  good=dict(bad,targetUid=uid(ordinary));ws.send(dict(base,type='save_turn_draft',sequence=2,commands=[good]))
  ws.type('turn_draft_saved')
  ws.send({'type':'request_game_state','gameId':game});saved=ws.type('game_state_update')
  check('legal non-royal Cast draft survives snapshot '+str(index),saved.get('turnDraft',{}).get('commands')==[good])
  ws.send(dict(base,type='save_turn_draft',sequence=3,commands=[]));ws.type('turn_draft_saved')
  ws.send(dict(base,type='commit_turn',sequence=4,commands=[good,{'type':'pass_turn'}]));ws.type('turn_draft_saved')
  state=ws.until(lambda m:m.get('type')=='game_state_update' and m.get('committedTurn')==base['turnNumber'],'accepted cast')
  players[1-index].until(lambda m:m.get('type')=='game_state_update' and m.get('revision')==state['revision'],'opponent sees cast')
  check('legal Cast changes only non-royal control '+str(index),state['boardState'][ordinary]['color']==('white' if index==0 else 'black') and state['boardState'][king]['color']==('black' if index==0 else 'white'))
 check('original control returns on next caster turn',state['boardState']['0,1']['color']=='black')
 Path(__file__).with_suffix('.json').write_text(json.dumps({'checks':len(results),'passed':all(results)}))
 assert all(results),results
finally:
 for ws in sockets:ws.close()
