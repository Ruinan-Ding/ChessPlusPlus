import os,sys,unittest
from pathlib import Path
os.environ.update(DJANGO_DEBUG='true',DJANGO_SETTINGS_MODULE='core.settings')
root=Path(r'C:\Users\DRuin\OneDrive\Documents\ChessPlusPlus');sys.path.insert(0,str(root/'server'));os.chdir(root/'server')
import django;django.setup()
from game.testsuite import test_cpu
from game.testsuite.test_cpu import CpuTests
import types,time
baseline=types.ModuleType('game.pre_cast_cpu');baseline.__package__='game';baseline.__file__=str(root/'server/game/cpu.py')
sys.modules[baseline.__name__]=baseline
exec(compile((Path(__file__).parent/'pre-cast-cpu.py').read_text(encoding='utf-8'), baseline.__file__, 'exec'),baseline.__dict__)
baseline.time=types.SimpleNamespace(monotonic=time.process_time)
test_cpu.search_turn=baseline.search_turn
suite=unittest.TestSuite(CpuTests('test_retreats_a_wounded_commander_instead_of_chasing_capture_points') for _ in range(4))
r=unittest.TextTestRunner(verbosity=2).run(suite);sys.exit(not r.wasSuccessful())
