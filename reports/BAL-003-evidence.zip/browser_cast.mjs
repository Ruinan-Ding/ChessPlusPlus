import {spawn} from 'node:child_process';
import {mkdtempSync,rmSync,writeFileSync,readFileSync} from 'node:fs';
import {tmpdir} from 'node:os';import {join} from 'node:path';
const CHROME="C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe"; const PORT=9357;
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function launch(port = PORT) {
  const profile = mkdtempSync(join(tmpdir(), 'cpp-layout-'));
  const chrome = spawn(CHROME, ['--headless=new', `--remote-debugging-port=${port}`, `--user-data-dir=${profile}`,
    '--no-first-run', '--no-default-browser-check', '--hide-scrollbars', 'about:blank'], { stdio: 'ignore' });
  // The profile goes once Chrome has let it go. Removed the moment it was
  // killed, Chrome still held it, and every run left one in the temp folder;
  // the retries wait up to a second on the busy files a Windows exit leaves.
  const kill = () => {
    chrome.kill();
    try {
      rmSync(profile, { recursive: true, force: true, maxRetries: 10, retryDelay: 100 });
    } catch { /* Chrome still has it */ }
  };
  // Until close() is handed back, the caller has nothing to shut it with: a
  // Chrome slow to start, or a port already taken, left a headless Chrome
  // listening on it and its profile in the temp folder.
  let ws;
  try {
    let wsUrl;
    for (let i = 0; i < 100 && !wsUrl; i++) {
      try {
        const list = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
        wsUrl = list.find((t) => t.type === 'page')?.webSocketDebuggerUrl;
      } catch { /* not up yet */ }
      if (!wsUrl) await sleep(100);
    }
    if (!wsUrl) throw new Error(`no Chrome on ${port} (CHROME=${CHROME})`);
    ws = new WebSocket(wsUrl);
    await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
  } catch (e) {
    try { ws?.close(); } catch { /* gone */ }
    kill();
    throw e;
  }
  let id = 1;
  const pending = new Map();
  ws.onmessage = (m) => {
    const x = JSON.parse(m.data);
    if (pending.has(x.id)) { pending.get(x.id)(x.result ?? x.error); pending.delete(x.id); }
  };
  const send = (method, params = {}) => new Promise((res) => {
    const i = id++; pending.set(i, res); ws.send(JSON.stringify({ id: i, method, params }));
  });
  const ev = async (expression) => {
    const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true });
    if (r?.exceptionDetails) throw new Error(r.exceptionDetails.exception?.description ?? r.exceptionDetails.text);
    return r?.result?.value;
  };
  const close = () => {
    try { ws.close(); } catch { /* gone */ }
    kill();
  };
  try {
    await send('Page.enable');
    await send('Runtime.enable');
  } catch (e) {
    close();
    throw e;
  }
  return { send, ev, close };
}

const {send,ev,close}=await launch();const checks=[];
const check=(name,ok)=>{checks.push({name,ok});console.log((ok?'PASS ':'FAIL ')+name);if(!ok)throw Error(name)};
const click=async(selector,label)=>ev(`(()=>{const e=[...document.querySelectorAll(${JSON.stringify(selector)})].find(b=>!${JSON.stringify(label)}||b.textContent.trim().startsWith(${JSON.stringify(label)}));if(!e||e.disabled)return false;e.click();return true})()`);
const wait=async(test)=>{for(let i=0;i<100;i++){if(await ev(test))return;await sleep(100)}throw Error('wait '+test)};
const room=expression=>ev(`(()=>{const c=ng.getComponent(document.querySelector('app-game-room'));return (${expression})})()`);
const hex=async(key)=>{const ok=await ev(`(()=>{const b=ng.getComponent(document.querySelector('app-game-board'));const cell=b.cells.find(c=>c.key===${JSON.stringify(key)});const p=[...document.querySelectorAll('polygon.hex-cell')].find(p=>p.getAttribute('points')===cell.points);if(!p)return false;p.dispatchEvent(new MouseEvent('click',{bubbles:true}));return true})()`);check('click hex '+key,ok);await sleep(150)};
try{
 await send('Emulation.setDeviceMetricsOverride',{width:1920,height:1080,deviceScaleFactor:1,mobile:false});
 await send('Page.navigate',{url:'http://127.0.0.1:4217/login'});await sleep(2500);
 await ev(`localStorage.setItem('username','CastBrowser');sessionStorage.setItem('cpp.offline','1');1`);
 await send('Page.navigate',{url:'http://127.0.0.1:4217/lobby'});
 await wait(`!![...document.querySelectorAll('button')].find(b=>b.textContent.trim()==='Single Player')`);
 check('enter solo from lobby',await click('button','Single Player'));await wait(`!!document.querySelector('.start-game-btn')`);
 const config=JSON.parse(readFileSync(new URL('browser-config.json',import.meta.url),'utf8'));
 check('custom current config accepted',await room(`c.configService.updateConfig(${JSON.stringify(JSON.stringify(config))}).valid`));
 check('custom mode control',await click('#custom-mode',''));await sleep(100);
 check('start control',await click('.start-game-btn',''));await wait(`!!document.querySelector('app-game-board svg')`);await sleep(1500);
 const arm=async()=>{await hex('0,0');check('inspect Cast',await click('.stats-panel .unit-ability-row button','Cast'));await sleep(100);check('description shows commander exclusion',await ev(`document.querySelector('.stats-panel').textContent.includes('Cannot target commanders')`));check('arm Cast',await click('.stats-panel .ability-detail-actions button','Use'));await sleep(150)};
 await arm();
 check('king lacks target highlight',await room(`!c.boardRef.isAbilityTarget(c.boardRef.cells.find(cell=>cell.key==='1,0'),'enemy')`));
 check('ordinary enemy highlighted',await room(`c.boardRef.isAbilityTarget(c.boardRef.cells.find(cell=>cell.key==='0,1'),'enemy')`));
 await hex('1,0');check('invalid king click spends nothing',await room(`c.myUnitPoints===100&&c.stagedActions.length===0`));
 await arm();await hex('0,1');await sleep(1200);check('ordinary Cast spends 32 UP',await room(`c.myUnitPoints===68&&c.stagedBoard['0,1'].color==='white'`));
 await send('Page.reload');await wait(`!!document.querySelector('app-game-board svg')`);await sleep(1300);
 check('staged ordinary Cast survives reload',await room(`c.myUnitPoints===68&&c.stagedBoard['0,1'].color==='white'`));
 check('Undo control',await click('.undo-btn',''));await sleep(250);check('Undo restores UP',await room(`c.myUnitPoints===100`));
 await arm();await hex('0,1');await sleep(1200);check('End Turn control',await click('.end-turn-btn',''));await sleep(3000);
 check('legal Cast committed without king control',await room(`c.gameState.snapshot.turnNumber===2&&c.gameState.snapshot.boardState['0,1'].color==='white'&&c.gameState.snapshot.boardState['1,0'].color==='black'`));
 const png=await send('Page.captureScreenshot',{format:'png'});writeFileSync(new URL('browser-cast.png',import.meta.url),Buffer.from(png.data,'base64'));
 writeFileSync(new URL('browser-checks.json',import.meta.url),JSON.stringify(checks,null,2));
}finally{close()}
