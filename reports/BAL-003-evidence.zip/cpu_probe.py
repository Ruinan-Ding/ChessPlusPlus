import os,sys,unittest
from pathlib import Path
os.environ.update(DJANGO_DEBUG='true',DJANGO_SETTINGS_MODULE='core.settings')
root=Path(r'C:\Users\DRuin\OneDrive\Documents\ChessPlusPlus');sys.path.insert(0,str(root/'server'));os.chdir(root/'server')
import django;django.setup()
from game.testsuite.test_cpu import CpuTests
suite=unittest.TestSuite(CpuTests('test_retreats_a_wounded_commander_instead_of_chasing_capture_points') for _ in range(4))
r=unittest.TextTestRunner(verbosity=2).run(suite);sys.exit(not r.wasSuccessful())
