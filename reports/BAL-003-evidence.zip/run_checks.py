import os, sys, subprocess, pathlib, time
sys.stdout.reconfigure(encoding='utf-8',errors='replace')
root=pathlib.Path(r'C:\Users\DRuin\OneDrive\Documents\ChessPlusPlus')
evidence=pathlib.Path(__file__).parent
env=dict(os.environ,DJANGO_DEBUG='true',DJANGO_DB_PATH=str(evidence/'checks.sqlite3'))
kind=sys.argv[1]; python=root/'server/venv/Scripts/python.exe';node=pathlib.Path(r'C:\Program Files\nodejs\node.exe')
if kind in ('backend-focus','backend-full','drift'):
 cwd=root/'server';cmd=[str(python),'manage.py']
 if kind=='drift':cmd+=['makemigrations','--check','--dry-run']
 elif kind=='backend-full':cmd+=['test','game.testsuite','--verbosity=1']
 else:cmd+=['test','game.testsuite.test_online_abilities.OnlineAbilityRulesTests','game.testsuite.test_config_parity','game.testsuite.test_cpu.CpuTests.test_cast_candidates_exclude_commanders_before_target_shortlisting','--verbosity=1']
else:
 cwd=root/'client';cmd=[str(node),'node_modules/@angular/cli/bin/ng.js']
 if kind=='build':cmd+=['build']
 else:
  cmd+=['test','--watch=false','--browsers=ChromeHeadless','--progress=false']
  if kind=='client-focus':
   for spec in ('components/game-room/game-room.integration.spec.ts','services/local-game.service.spec.ts','services/config.service.spec.ts','services/game-rules.spec.ts'):cmd+=['--include=src/app/'+spec]
start=time.time()
with (evidence/(kind+'.log')).open('w',encoding='utf-8') as log:
 result=subprocess.run(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
lines=(evidence/(kind+'.log')).read_text(encoding='utf-8',errors='replace').splitlines()
print(kind,'exit',result.returncode,'seconds',round(time.time()-start,1),flush=True)
print('\n'.join(lines[-35:]),flush=True)
sys.exit(result.returncode)
