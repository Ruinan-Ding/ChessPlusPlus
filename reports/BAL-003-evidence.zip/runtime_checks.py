import os,sys,subprocess,socket,time,pathlib,urllib.request
sys.stdout.reconfigure(encoding='utf-8',errors='replace')
root=pathlib.Path(r'C:\Users\DRuin\OneDrive\Documents\ChessPlusPlus');ev=pathlib.Path(__file__).parent
python=root/'server/venv/Scripts/python.exe';node=pathlib.Path(r'C:\Program Files\nodejs\node.exe')
env=dict(os.environ,DJANGO_DEBUG='true',DJANGO_SETTINGS_MODULE='core.settings',DJANGO_DB_PATH=str(ev/'runtime.sqlite3'),E2E_PORT='18127',E2E_ORIGIN='http://127.0.0.1:4217',PYTHONIOENCODING='utf-8')
processes=[];logs=[]
def start(cmd,cwd,log):
 f=(ev/log).open('w',encoding='utf-8');logs.append(f)
 p=subprocess.Popen(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT);processes.append(p);return p
def wait_port(port,p):
 for _ in range(240):
  if p.poll() is not None:raise RuntimeError('server stopped '+str(p.returncode))
  try:
   with socket.create_connection(('127.0.0.1',port),timeout=.2):return
  except OSError:time.sleep(.25)
 raise RuntimeError('server did not open '+str(port))
try:
 for port in (18127,4217,9357):
  with socket.socket() as s:s.bind(('127.0.0.1',port))
 with (ev/'runtime-migrate.log').open('w') as f:subprocess.run([str(python),'manage.py','migrate','--noinput'],cwd=root/'server',env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 back=start([str(python),'-m','daphne','-b','127.0.0.1','-p','18127','core.asgi:application'],root/'server','daphne.log');wait_port(18127,back)
 subprocess.run([str(python),str(ev/'live_cast.py')],env=env,check=True)
 front=start([str(node),'node_modules/@angular/cli/bin/ng.js','serve','--port','4217','--host','127.0.0.1'],root/'client','ng-serve.log');wait_port(4217,front)
 for _ in range(120):
  try:
   if urllib.request.urlopen('http://127.0.0.1:4217',timeout=2).status==200:break
  except Exception:time.sleep(.5)
 subprocess.run([str(node),str(ev/'browser_cast.mjs')],cwd=root/'client',env=env,check=True)
finally:
 for p in reversed(processes):
  if p.poll() is None:
   p.terminate()
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:p.kill();p.wait(timeout=5)
 for f in logs:f.close()
